package com.example.vision_h_plus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
